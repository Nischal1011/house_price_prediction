import joblib
import os
import json
import numpy as np

def model_fn(model_dir: str):
    """
    Deserialize fitted model
    """
    model_artifcat = joblib.load(os.path.join(model_dir, "xg_boost_model.joblib"))
    return model_artifcat


def input_fn(request_body, request_content_type):
    if request_content_type == 'application/json':
        request_body = json.loads(request_body)
        inpVar = request_body['Input']
        return inpVar
    elif request_content_type == 'text/csv':
        import pandas as pd
        # If already a DataFrame, return it directly
        if isinstance(request_body, pd.DataFrame):
            return request_body
        # Otherwise, process as CSV string
        else:
            import io
            return pd.read_csv(io.StringIO(request_body))
    else:
        raise ValueError("This model only supports application/json and text/csv input")


def predict_fn(input_data, model):
    y_pred_test_xgb = model.predict(input_data)
    predicted_sale_price = np.expm1(y_pred_test_xgb)
    return predicted_sale_price






  